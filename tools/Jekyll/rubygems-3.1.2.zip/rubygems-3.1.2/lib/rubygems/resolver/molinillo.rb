# frozen_string_literal: true
require 'rubygems/resolver/molinillo/lib/molinillo'
